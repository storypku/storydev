.. cmake-module:: ../../Modules/FindIcotool.cmake
